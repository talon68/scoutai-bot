import os
import json
import asyncio
import aiohttp
from datetime import datetime, timezone
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8764760265:AAFe3FSKokjQYgWvwoMV_E6x7y0zicAKuH8")
FOOTBALL_KEY = os.environ.get("FOOTBALL_KEY", "27902ede72a3435eb01e175bcad36297")
ANTHROPIC_KEY = os.environ.get("ANTHROPIC_KEY", "")

# ─── Football API ───────────────────────────────────────────────
async def get_todays_matches():
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    url = f"https://api.football-data.org/v4/matches?dateFrom={today}&dateTo={today}"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers={"X-Auth-Token": FOOTBALL_KEY}) as r:
            if r.status != 200:
                return []
            data = await r.json()
            return data.get("matches", [])

async def get_live_matches():
    url = "https://api.football-data.org/v4/matches?status=IN_PLAY"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers={"X-Auth-Token": FOOTBALL_KEY}) as r:
            if r.status != 200:
                return []
            data = await r.json()
            return data.get("matches", [])

# ─── Claude AI Analiz ───────────────────────────────────────────
async def analyze_with_claude(home, away, league="", score=""):
    if not ANTHROPIC_KEY:
        return analiz_without_ai(home, away)

    score_info = f"Mevcut skor: {score}" if score else "Maç henüz başlamadı"
    prompt = f"""Sen profesyonel bir futbol maç analisti yapay zekasısın. Şu maçı analiz et:

MAÇ: {home} vs {away}
LİG: {league or 'Bilinmiyor'}
DURUM: {score_info}

SADECE şu JSON formatında yanıt ver:
{{
  "ozet": "2 cümle maç özeti",
  "confidence": 75,
  "surprizOlasiligi": 30,
  "iymsTablosu": [
    {{"tahmini":"1/1","oran":"40%"}},
    {{"tahmini":"X/1","oran":"20%"}},
    {{"tahmini":"1/2","oran":"15%"}},
    {{"tahmini":"X/X","oran":"15%"}},
    {{"tahmini":"2/2","oran":"10%"}}
  ],
  "iymsYorum": "en güçlü İY/MS tahmini açıklaması",
  "golOlasiligi": 45,
  "golYorum": "gol beklentisi analizi"
}}"""

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.anthropic.com/v1/messages",
            headers={"Content-Type": "application/json", "x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01"},
            json={"model": "claude-sonnet-4-20250514", "max_tokens": 800, "messages": [{"role": "user", "content": prompt}]}
        ) as r:
            data = await r.json()
            raw = "".join(b.get("text", "") for b in data.get("content", []))
            clean = raw.replace("```json", "").replace("```", "").strip()
            return json.loads(clean)

def analiz_without_ai(home, away):
    """Anthropic key yoksa basit analiz"""
    return {
        "ozet": f"{home} ve {away} arasındaki maç için detaylı AI analizi için Anthropic key gerekiyor.",
        "confidence": 60,
        "surprizOlasiligi": 25,
        "iymsTablosu": [
            {"tahmini":"1/1","oran":"38%"},
            {"tahmini":"X/1","oran":"18%"},
            {"tahmini":"1/2","oran":"14%"},
            {"tahmini":"X/X","oran":"16%"},
            {"tahmini":"2/2","oran":"14%"}
        ],
        "iymsYorum": "İstatistiksel ortalamaya göre ev sahibi avantajlı.",
        "golOlasiligi": 42,
        "golYorum": "Ortalama gol beklentisi 2.4 civarında."
    }

def format_match_status(m):
    st = m.get("status", "")
    if st in ("IN_PLAY", "PAUSED"):
        return "🔴 CANLI"
    elif st == "FINISHED":
        ih = m.get("score", {}).get("halfTime", {})
        iy = f" · İY:{ih.get('home','-')}-{ih.get('away','-')}" if ih.get('home') is not None else ""
        return f"✅ BİTTİ{iy}"
    else:
        try:
            t = datetime.fromisoformat(m["utcDate"].replace("Z","+00:00"))
            local = t.strftime("%H:%M")
            return f"🕐 {local}"
        except:
            return "📅 Planlandı"

def format_score(m):
    ft = m.get("score", {}).get("fullTime", {})
    h, a = ft.get("home"), ft.get("away")
    if h is not None and a is not None:
        return f"{h} - {a}"
    ht = m.get("score", {}).get("halfTime", {})
    h, a = ht.get("home"), ht.get("away")
    if h is not None and a is not None:
        return f"{h} - {a}"
    return "- : -"

# ─── Komutlar ───────────────────────────────────────────────────

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "⚽ *ScoutAI Maç Analiz Botu*\n\n"
        "Merhaba! Maçları analiz edebilir, canlı skorları takip edebilirsin.\n\n"
        "*Komutlar:*\n"
        "🔴 /canli — Canlı maçlar\n"
        "📅 /bugun — Bugünkü program\n"
        "🎯 /analiz — Maç analizi yap\n"
        "❓ /yardim — Yardım\n\n"
        "_Örnek: /analiz Galatasaray Fenerbahçe_"
    )
    kb = [
        [InlineKeyboardButton("🔴 Canlı Maçlar", callback_data="live"),
         InlineKeyboardButton("📅 Bugün", callback_data="today")],
        [InlineKeyboardButton("🎯 Analiz Yap", callback_data="help_analiz")]
    ]
    await update.message.reply_text(text, parse_mode="Markdown",
                                    reply_markup=InlineKeyboardMarkup(kb))

async def cmd_yardim(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 *Kullanım Kılavuzu*\n\n"
        "*Canlı & Bugün:*\n"
        "`/canli` — Şu an oynanan maçlar\n"
        "`/bugun` — Bugünün tüm maçları\n\n"
        "*Analiz:*\n"
        "`/analiz Galatasaray Fenerbahçe`\n"
        "`/analiz ManCity Arsenal Premier League`\n\n"
        "*Tıklama:*\n"
        "Maç listesinde bir maça tıklayarak da analiz yaptırabilirsin!"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def cmd_canli(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("🔴 Canlı maçlar getiriliyor...")
    matches = await get_live_matches()

    if not matches:
        await msg.edit_text("🔴 Şu an canlı maç yok.\n\n📅 /bugun ile bugünkü programa bakabilirsin.")
        return

    text = "🔴 *CANLI MAÇLAR*\n\n"
    buttons = []
    for m in matches[:15]:
        home = m["homeTeam"].get("shortName") or m["homeTeam"]["name"]
        away = m["awayTeam"].get("shortName") or m["awayTeam"]["name"]
        score = format_score(m)
        league = m["competition"]["name"]
        text += f"⚽ *{home}* {score} *{away}*\n_{league}_\n\n"
        mid = str(m["id"])
        buttons.append([InlineKeyboardButton(
            f"🎯 {home} vs {away} analiz et",
            callback_data=f"match_{mid}_{home[:10]}_{away[:10]}"
        )])

    buttons.append([InlineKeyboardButton("🔄 Yenile", callback_data="live")])
    await msg.edit_text(text, parse_mode="Markdown",
                        reply_markup=InlineKeyboardMarkup(buttons))

async def cmd_bugun(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("📅 Bugünkü maçlar yükleniyor...")
    matches = await get_todays_matches()

    if not matches:
        await msg.edit_text("📅 Bugün maç bulunamadı.")
        return

    text = f"📅 *BUGÜNKÜ MAÇLAR* ({datetime.now().strftime('%d.%m.%Y')})\n\n"
    buttons = []

    current_league = ""
    for m in matches[:20]:
        league = m["competition"]["name"]
        home = m["homeTeam"].get("shortName") or m["homeTeam"]["name"]
        away = m["awayTeam"].get("shortName") or m["awayTeam"]["name"]
        score = format_score(m)
        status = format_match_status(m)

        if league != current_league:
            text += f"🏆 *{league}*\n"
            current_league = league

        text += f"  {status} | {home} {score} {away}\n"
        mid = str(m["id"])
        buttons.append([InlineKeyboardButton(
            f"🎯 {home} vs {away}",
            callback_data=f"match_{mid}_{home[:10]}_{away[:10]}"
        )])

    buttons.append([InlineKeyboardButton("🔄 Yenile", callback_data="today")])
    await msg.edit_text(text, parse_mode="Markdown",
                        reply_markup=InlineKeyboardMarkup(buttons))

async def cmd_analiz(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    args = ctx.args
    if len(args) < 2:
        await update.message.reply_text(
            "❌ Kullanım: `/analiz EvSahibi Deplasman [Lig]`\n\n"
            "Örnek: `/analiz Galatasaray Fenerbahçe SüperLig`",
            parse_mode="Markdown"
        )
        return

    home = args[0]
    away = args[1]
    league = " ".join(args[2:]) if len(args) > 2 else ""

    msg = await update.message.reply_text(f"🤖 *{home}* vs *{away}* analiz ediliyor...", parse_mode="Markdown")
    await do_analysis(msg, home, away, league, "")

async def do_analysis(msg, home, away, league, score):
    try:
        r = await analyze_with_claude(home, away, league, score)
    except Exception as e:
        await msg.edit_text(f"⚠️ Analiz hatası: {str(e)[:100]}")
        return

    score_display = f" | Skor: {score}" if score else ""
    text = (
        f"🎯 *MAÇ ANALİZİ*\n"
        f"⚽ *{home}* vs *{away}*{score_display}\n"
        f"{'🏆 ' + league if league else ''}\n\n"
        f"📋 *Özet:*\n{r.get('ozet','')}\n\n"
        f"📊 *Tahmin Güveni:* `{r.get('confidence',70)}%`\n"
        f"🎲 *Sürpriz İhtimali:* `{r.get('surprizOlasiligi',25)}%`\n\n"
    )

    # İY/MS
    iyms = r.get("iymsTablosu", [])
    if iyms:
        text += "⏱ *İY/MS Tablosu:*\n"
        for item in iyms:
            bar_len = int(int(item['oran'].replace('%','')) / 10)
            bar = "█" * bar_len + "░" * (10 - bar_len)
            text += f"`{item['tahmini']}` {bar} {item['oran']}\n"
        if r.get("iymsYorum"):
            text += f"💡 _{r['iymsYorum']}_\n"
        text += "\n"

    # Gol
    if r.get("golOlasiligi") is not None:
        text += f"⚽ *+6 Gol / Üst:* `{r.get('golOlasiligi')}%`\n"
        if r.get("golYorum"):
            text += f"_{r['golYorum']}_\n"

    await msg.edit_text(text, parse_mode="Markdown")

# ─── Callback (buton tıklama) ────────────────────────────────────

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data

    if data == "live":
        matches = await get_live_matches()
        if not matches:
            await q.edit_message_text("🔴 Şu an canlı maç yok.\n\n📅 /bugun ile programa bak.")
            return
        text = "🔴 *CANLI MAÇLAR*\n\n"
        buttons = []
        for m in matches[:15]:
            home = m["homeTeam"].get("shortName") or m["homeTeam"]["name"]
            away = m["awayTeam"].get("shortName") or m["awayTeam"]["name"]
            score = format_score(m)
            league = m["competition"]["name"]
            text += f"⚽ *{home}* {score} *{away}*\n_{league}_\n\n"
            mid = str(m["id"])
            buttons.append([InlineKeyboardButton(f"🎯 Analiz: {home} vs {away}", callback_data=f"match_{mid}_{home[:10]}_{away[:10]}")])
        buttons.append([InlineKeyboardButton("🔄 Yenile", callback_data="live")])
        await q.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))

    elif data == "today":
        matches = await get_todays_matches()
        if not matches:
            await q.edit_message_text("📅 Bugün maç bulunamadı.")
            return
        text = f"📅 *BUGÜN* ({datetime.now().strftime('%d.%m.%Y')})\n\n"
        buttons = []
        cl = ""
        for m in matches[:20]:
            league = m["competition"]["name"]
            home = m["homeTeam"].get("shortName") or m["homeTeam"]["name"]
            away = m["awayTeam"].get("shortName") or m["awayTeam"]["name"]
            score = format_score(m)
            status = format_match_status(m)
            if league != cl:
                text += f"🏆 *{league}*\n"; cl = league
            text += f"  {status} | {home} {score} {away}\n"
            mid = str(m["id"])
            buttons.append([InlineKeyboardButton(f"🎯 {home} vs {away}", callback_data=f"match_{mid}_{home[:10]}_{away[:10]}")])
        buttons.append([InlineKeyboardButton("🔄 Yenile", callback_data="today")])
        await q.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))

    elif data == "help_analiz":
        await q.edit_message_text(
            "🎯 *Analiz Yapmak İçin:*\n\n"
            "`/analiz EvSahibi Deplasman`\n\n"
            "Örnek:\n"
            "`/analiz Galatasaray Fenerbahçe`\n"
            "`/analiz ManCity Arsenal`\n\n"
            "Veya /bugun listesinden bir maça tıkla!",
            parse_mode="Markdown"
        )

    elif data.startswith("match_"):
        parts = data.split("_", 3)
        # match_{id}_{home}_{away}
        home = parts[2] if len(parts) > 2 else "Ev"
        away = parts[3] if len(parts) > 3 else "Dep"
        await q.edit_message_text(f"🤖 *{home}* vs *{away}* analiz ediliyor...", parse_mode="Markdown")
        await do_analysis(q.message, home, away, "", "")

# ─── Main ────────────────────────────────────────────────────────

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("yardim", cmd_yardim))
    app.add_handler(CommandHandler("canli", cmd_canli))
    app.add_handler(CommandHandler("bugun", cmd_bugun))
    app.add_handler(CommandHandler("analiz", cmd_analiz))
    app.add_handler(CallbackQueryHandler(handle_callback))
    print("🚀 ScoutAI Bot başlatıldı!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
